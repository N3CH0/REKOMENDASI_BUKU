var libraryData = {
  "category_1": [
    { "title": "Eloquent JavaScript", "author": "Marijn Haverbeke", "year": "2018", "img": "resource/img/eloquent_javascript.jpg" },
    { "title": "Clean Code", "author": "Robert C. Martin", "year": "2008", "img": "resource/img/Clean_Code.jpg" },
    { "title": "You Don't Know JS Yet", "author": "Kyle Simpson", "year": "2020", "img": "resource/img/You_Don't_Know_JS_Yet.jpg" },
    { "title": "The Pragmatic Programmer", "author": "Andrew Hunt", "year": "2019", "img": "resource/img/pragmatic_programmer.jpg" },
    { "title": "Learning Web Design", "author": "Jennifer Robbins", "year": "2018", "img": "resource/img/Learning_Web.jpg" }
  ],
  "category_2": [
    { "title": "Laskar Pelangi", "author": "Andrea Hirata", "year": "2005", "img": "resource/img/Laskar_pelangi.jpg" },
    { "title": "Bumi", "author": "Tere Liye", "year": "2014", "img": "resource/img/Bumi.jpg" },
    { "title": "Laut Bercerita", "author": "Leila S. Chudori", "year": "2017", "img": "resource/img/Laut_Bercerita.jpg" },
    { "title": "Gadis Kretek", "author": "Ratih Kumala", "year": "2012", "img": "resource/img/Gadis_Kretek.jpg" },
    { "title": "Perahu Kertas", "author": "Dee Lestari", "year": "2009", "img": "resource/img/Perahu_Kertas.jpg" }
  ],
  "category_3": [
    { "title": "Atomic Habits", "author": "James Clear", "year": "2018", "img": "resource/img/Atomic_Habits.jpg" },
    { "title": "Filosofi Teras", "author": "Henry Manampiring", "year": "2018", "img": "resource/img/Filosofi_Teras.jpg" },
    { "title": "Berani Tidak Disukai", "author": "Ichiro Kishimi", "year": "2019", "img": "resource/img/Berani_Tidak_Disukai.jpg" },
    { "title": "Start With Why", "author": "Simon Sinek", "year": "2009", "img": "resource/img/Start_With_Why.jpg" },
    { "title": "Psychology of Money", "author": "Morgan Housel", "year": "2020", "img": "resource/img/Psychology_Money.jpg" }
  ]
};