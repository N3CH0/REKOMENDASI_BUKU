var abstractData = {
  "category_1": [
    { "abstract": "Buku panduan mendalam untuk belajar JavaScript modern. Buku ini mengajarkan dasar pemrograman hingga manipulasi browser (DOM) secara interaktif." },
    { "abstract": "Buku legendaris yang mengajarkan cara menulis kode yang bersih, rapi, dan mudah dirawat demi keberlanjutan sebuah proyek software." },
    { "abstract": "Menyelami mekanisme terdalam bahasa pemrograman JavaScript. Sangat cocok bagi developer yang ingin memahami cara kerja JS secara mendetail." },
    { "abstract": "Berisi tips, efisiensi kerja, dan tips karier praktis bagi programmer agar bisa menjadi developer yang profesional dan pragmatis." },
    { "abstract": "Panduan ramah pemula untuk membangun halaman web modern menggunakan dasar HTML5, CSS3, hingga dasar desain web responsif." }
  ],
  "category_2": [
    { "abstract": "Kisah inspiratif sebelas anak di Pulau Belitong yang berjuang mengejar mimpi di tengah keterbatasan fasilitas sekolah yang minim." },
    { "abstract": "Petualangan fantasi seru tiga remaja SMA di dunia paralel yang membuka rahasia besar tentang kekuatan tersembunyi klan bumi dan bulan." },
    { "abstract": "Novel sejarah emosional yang mengangkat kisah perjuangan aktivis mahasiswa di era Orde Baru dan duka mendalam keluarga yang ditinggalkan." },
    { "abstract": "Kisah drama romansa berlatar belakang sejarah industri kretek lokal di Indonesia, penuh dengan intrik bisnis keluarga dan budaya Jawa." },
    { "abstract": "Kisah perjalanan Kugy dan Keenan dalam mengejar cita-cita, cinta, dan idealisme masa muda yang dibalut secara hangat dan puitis." }
  ],
  "category_3": [
    { "abstract": "Strategi praktis mengubah hidup lewat perubahan kecil yang konsisten setiap hari dengan memahami psikologi pembentukan kebiasaan baru." },
    { "abstract": "Penerapan ilmu filsafat kuno Stoisisme (Stoik) secara santai untuk membantu masyarakat modern mengatasi kecemasan dan emosi negatif." },
    { "abstract": "Mengupas prinsip psikologi Alfred Adler tentang cara menemukan kebahagiaan sejati dengan berani melepaskan diri dari ekspektasi orang lain." },
    { "abstract": "Menginspirasi para pemimpin dan organisasi untuk memulai segala tindakan dari pertanyaan 'Mengapa' demi menciptakan dampak yang besar." },
    { "abstract": "Menjelaskan bahwa mengelola keuangan bukan sekadar soal matematika cerdas, melainkan tentang perilaku, emosi, dan ego manusia terhadap uang." }
  ]
};