var abstractData = {
  "category_1": [
    { "abstract": "abstract_1_1" },
    { "abstract": "abstract_1_2" },
    { "abstract": "abstract_1_3" },
    { "abstract": "abstract_1_4" },
    { "abstract": "abstract_1_5" }
  ],
  "category_2": [
    { "abstract": "abstract_2_1" },
    { "abstract": "abstract_2_2" },
    { "abstract": "abstract_2_3" },
    { "abstract": "abstract_2_4" },
    { "abstract": "abstract_2_5" }
  ],
  "category_3": [
    { "abstract": "abstract_3_1" },
    { "abstract": "abstract_3_2" },
    { "abstract": "abstract_3_3" },
    { "abstract": "abstract_3_4" },
    { "abstract": "abstract_3_5" }
  ]
};
