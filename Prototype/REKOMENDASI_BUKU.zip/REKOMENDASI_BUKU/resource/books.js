var libraryData = {
  "category_1": [
    { "title": "Book_1_1", "author": "Name_1_1", "year": "yyyy", "img": "resource/img/book_1_1.png" },
    { "title": "Book_1_2", "author": "Name_1_2", "year": "yyyy", "img": "resource/img/book_1_2.png" },
    { "title": "Book_1_3", "author": "Name_1_3", "year": "yyyy", "img": "resource/img/book_1_3.png" },
    { "title": "Book_1_4", "author": "Name_1_4", "year": "yyyy", "img": "resource/img/book_1_4.png" },
    { "title": "Book_1_5", "author": "Name_1_5", "year": "yyyy", "img": "resource/img/book_1_5.png" }
  ],
  "category_2": [
    { "title": "Book_2_1", "author": "Name_2_1", "year": "yyyy", "img": "resource/img/book_2_1.png" },
    { "title": "Book_2_2", "author": "Name_2_2", "year": "yyyy", "img": "resource/img/book_2_2.png" },
    { "title": "Book_2_3", "author": "Name_2_3", "year": "yyyy", "img": "resource/img/book_2_3.png" },
    { "title": "Book_2_4", "author": "Name_2_4", "year": "yyyy", "img": "resource/img/book_2_4.png" },
    { "title": "Book_2_5", "author": "Name_2_5", "year": "yyyy", "img": "resource/img/book_2_5.png" }
  ],
  "category_3": [
    { "title": "Book_3_1", "author": "Name_3_1", "year": "yyyy", "img": "resource/img/book_3_1.png" },
    { "title": "Book_3_2", "author": "Name_3_2", "year": "yyyy", "img": "resource/img/book_3_2.png" },
    { "title": "Book_3_3", "author": "Name_3_3", "year": "yyyy", "img": "resource/img/book_3_3.png" },
    { "title": "Book_3_4", "author": "Name_3_4", "year": "yyyy", "img": "resource/img/book_3_4.png" },
    { "title": "Book_3_5", "author": "Name_3_5", "year": "yyyy", "img": "resource/img/book_3_5.png" }
  ]
};
